export const DB_NAME = 'Chaiaurcode';
